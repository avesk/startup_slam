
### Know
* Basic understanding of Git (or other version control system, but really Git)
  * If you are unsure, check out this [Git tutorial](http://rogerdudler.github.io/git-guide/)
* Basic understanding of GitHub
  * If you are unsure, check out this [GitHub tutorial](https://guides.github.com/activities/hello-world/)

### Download
Any computer will work, but you will need:
* [Git](https://git-scm.com/) installed on your machine
* a [Github profile](https://github.com/) all ready created
