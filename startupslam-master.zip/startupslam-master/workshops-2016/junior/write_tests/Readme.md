# Write Tests: No, Seriously: Write Tests. - Clarke Brunsdon

### Required Tools

* Python
* Text-editor such as [Sublime](https://www.sublimetext.com/) or [Atom](https://atom.io/)
* [Git](https://git-scm.com/)
* Ability to clone repos
* Ability to Execute Python scripts

### Get Started

* Clone **[THIS](https://github.com/sendwithus/startupslam.git)** repo
* Open up this presentations directory
