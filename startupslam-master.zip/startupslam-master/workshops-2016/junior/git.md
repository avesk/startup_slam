
### Know
This is a fully introductory Git workshop, targeted at those who are totally new to it. We will be working on the command line, so basic command line commands (ls, cd etc) will be required.


### Download
Any computer will work, but you will need:
* [Git](https://git-scm.com/) installed on your machine
* a [Github profile](https://github.com/) already created
