#Audio Visualization with WebSockets

![](https://media.giphy.com/media/j3gsT2RsH9K0w/giphy.gif)
## Before the Workshop

* Install a modern web browser
  * [Chrome](https://www.google.com/chrome/)
  * [Firefox](https://www.mozilla.org/en-US/firefox/new/)
* Get a text editor
  * Try [Sublime](https://www.sublimetext.com/) or [Atom](https://atom.io/)
* Download the materials - **[HERE](http://workday.startupslam.io/workshop.zip)**
