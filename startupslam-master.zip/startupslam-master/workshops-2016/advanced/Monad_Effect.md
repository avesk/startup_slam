The Monad Effect for Fun and Profit - MetaLab

You just need [Elixir!](http://elixir-lang.org/) Most examples and code can be run in the [Elixir Playground](http://elixirplayground.com/), but to really dig in you'll want to have Elixir installed locally. All the necessary instructions for installing Elixir can be found [HERE](http://elixir-lang.org/install.html#distributions).

##Required Tools

* [Elixir](http://elixir-lang.org/)
* [Elixir Playground](http://elixirplayground.com/)

##Resources

* [Examples and Sample Code](https://github.com/metalabdesign/effects-workshop)
* [Slide deck](https://docs.google.com/presentation/d/1JwS5ZrjnFucpMSRyjIt5Sd_rHmUJoyIKN3vGJa8YrzA/edit?usp=sharing)
